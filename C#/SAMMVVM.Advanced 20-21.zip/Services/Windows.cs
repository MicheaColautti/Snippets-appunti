﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Services
{
    public static class Windows
    {
        public const string MainWindow = nameof(MainWindow);
    }
}
