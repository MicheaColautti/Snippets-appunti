﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Services
{
    public interface IShowAll
    {
        bool ShowAllData();
    }
}
