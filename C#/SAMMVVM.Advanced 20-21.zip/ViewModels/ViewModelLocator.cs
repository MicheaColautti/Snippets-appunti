﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.ViewModels
{
    public class ViewModelLocator
    {
        public MainViewModel MainViewModel => App.ServiceProvider.GetRequiredService<MainViewModel>();
        public AboutViewModel AboutViewModel => App.ServiceProvider.GetRequiredService<AboutViewModel>();
        //public AssociateStudentsViewModel AssociateStudents => App.ServiceProvider.GetRequiredService<AssociateStudentsViewModel>();
        //public CreateClassViewModel CreateClass => App.ServiceProvider.GetRequiredService<CreateClassViewModel>();
        //public ModifyStudentViewModel ModifyStudent => App.ServiceProvider.GetRequiredService<ModifyStudentViewModel>();
        //public SelectStudentToModifyViewModel SelectStudent => App.ServiceProvider.GetRequiredService<SelectStudentToModifyViewModel>();
    }
}
