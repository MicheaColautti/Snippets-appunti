﻿using DevExpress.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

namespace $safeprojectname$.ViewModels
{
    public abstract class BindableBaseSAMT : BindableBase
    {
        protected virtual bool SetValue<TClass, TMember>(TClass target, Expression<Func<TClass, TMember>> expression,
                                                         TMember value, [CallerMemberName] string propertyName = null)
        {
            var expr = (MemberExpression)expression.Body;
            var prop = (PropertyInfo)expr.Member;
            var propValue = prop.GetValue(target, null);
            if (object.Equals(propValue, value)) return false;
            prop.SetValue(target, value, null);
            this.RaisePropertyChanged(propertyName);
            return true;
        }
        protected virtual bool SetValue<TClass, TMember>(TClass target, Expression<Func<TClass, TMember>> expression,
                                                         TMember value, Action changedCallback, [CallerMemberName] string propertyName = null)
        {
            var expr = (MemberExpression)expression.Body;
            var prop = (PropertyInfo)expr.Member;
            var propValue = prop.GetValue(target, null);
            if (object.Equals(propValue, value)) return false;
            prop.SetValue(target, value, null);
            changedCallback?.Invoke();
            this.RaisePropertyChanged(propertyName);
            return true;
        }
    }

    public abstract class ViewModelBaseSAMT : ViewModelBase
    {
        protected virtual bool SetValue<TClass, TMember>(TClass target, Expression<Func<TClass, TMember>> expression,
                                                         TMember value, [CallerMemberName] string propertyName = null)
        {
            var expr = (MemberExpression)expression.Body;
            var prop = (PropertyInfo)expr.Member;
            var propValue = prop.GetValue(target, null);
            if (object.Equals(propValue, value)) return false;
            prop.SetValue(target, value, null);
            this.RaisePropertyChanged(propertyName);
            return true;
        }
        protected virtual bool SetValue<TClass, TMember>(TClass target, Expression<Func<TClass, TMember>> expression,
                                                         TMember value, Action changedCallback, [CallerMemberName] string propertyName = null)
        {
            var expr = (MemberExpression)expression.Body;
            var prop = (PropertyInfo)expr.Member;
            var propValue = prop.GetValue(target, null);
            if (object.Equals(propValue, value)) return false;
            prop.SetValue(target, value, null);
            changedCallback?.Invoke();
            this.RaisePropertyChanged(propertyName);
            return true;
        }
    }
}

