﻿using DevExpress.Mvvm;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.ViewModels
{
    public class MainViewModel : BindableBaseSAMT
    {
        #region =================== costanti ===================
        #endregion

        #region =================== membri statici =============
        #endregion

        #region =================== membri & proprietà =========
        private ViewModelBaseSAMT currentViewModel;
        public ViewModelBaseSAMT CurrentViewModel
        {
            get { return currentViewModel; }
            set { SetValue(ref currentViewModel, value); }
        }
        public DelegateCommand AboutCommand { get; private set; }
        #endregion

        #region =================== costruttori ================
        public MainViewModel()
        {
            AboutCommand = new DelegateCommand(OnAbout, CanAbout);
            

        }
        #endregion

        #region =================== metodi aiuto ===============
        private bool CanAbout()
        {
            return CurrentViewModel != App.ServiceProvider.GetRequiredService<AboutViewModel>();
        }

        private void OnAbout()
        {
            CurrentViewModel = App.ServiceProvider.GetRequiredService<AboutViewModel>();
        }
        #endregion

        #region =================== metodi generali ============
        #endregion
        //private readonly NavigationService navigationService;
    }
}
