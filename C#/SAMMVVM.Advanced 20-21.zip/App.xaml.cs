﻿using $safeprojectname$.Services;
using $safeprojectname$.ViewModels;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using DevExpress.Mvvm.POCO;
using System.Windows;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private readonly IHost host;
        public static IServiceProvider ServiceProvider { get; private set; }
        public App()
        {
            host = Host.CreateDefaultBuilder()
                  .ConfigureServices((context, services) =>
                  {
                      ConfigureServices(context.Configuration, services);
                  })
                   .Build();
            ServiceProvider = host.Services;
        }
        private void ConfigureServices(IConfiguration configuration,
          IServiceCollection services)
        {
            services.AddScoped<NavigationService>(serviceProvider =>
            {
                var navigationService = new NavigationService(serviceProvider);
                navigationService.Configure(Services.Windows.MainWindow, typeof(MainWindow));
                return navigationService;
            });
            services.AddTransient<MainWindow>();
            services.AddSingleton<MainViewModel>();
            services.AddSingleton<AboutViewModel>();
        }
        protected override async void OnStartup(StartupEventArgs e)
        {
            await host.StartAsync();
            var navigationService = ServiceProvider.GetRequiredService<NavigationService>();
            await navigationService.ShowAsync(Services.Windows.MainWindow);
            base.OnStartup(e);
        }
        protected override async void OnExit(ExitEventArgs e)
        {
            using (host)
            {
                await host.StopAsync(TimeSpan.FromSeconds(5));
            }
            base.OnExit(e);
        }
    }
}
